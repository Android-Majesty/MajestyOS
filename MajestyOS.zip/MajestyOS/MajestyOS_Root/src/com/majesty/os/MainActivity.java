package com.majesty.os;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private PCWindowManager windowManager;
    private RelativeLayout rootLayout;
    private ImageView wallpaper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Встановлюємо головний екран MajestyOS
        setContentView(R.layout.main);

        // Знаходимо елементи
        rootLayout = findViewById(R.id.o_strip_container);
        wallpaper = findViewById(R.id.wallpaper);
        ImageButton sButton = findViewById(R.id.start_button);
        WebView oStripWebView = findViewById(R.id.o_strip_browser);
        final TextView clock = findViewById(R.id.pc_clock);

        // 1. Ініціалізуємо менеджер вікон (Lenovo Style)
        windowManager = new PCWindowManager(this, rootLayout);

        // 2. Запускаємо браузер на робочому столі (O-Strip)
        BrowserStrip.init(oStripWebView, "https://www.google.com");

        // 3. Оновлюємо годинник на панелі (як на ПК)
        updateClock(clock);

        // 4. Кнопка "S" — відкриваємо папку MajestyOS
        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Створюємо вигляд папки з нашого XML
                View folderView = getLayoutInflater().inflate(R.layout.folder_view, null);
                
                // Відкриваємо це як вікно ПК
                windowManager.openNewWindow("Majesty: System Files", folderView);
            }
        });
    }

    // Функція для годинника
    private void updateClock(final TextView clock) {
        Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    while (!isInterrupted()) {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                                clock.setText(currentTime);
                            }
                        });
                    }
                } catch (InterruptedException e) {}
            }
        };
        t.start();
    }
}
