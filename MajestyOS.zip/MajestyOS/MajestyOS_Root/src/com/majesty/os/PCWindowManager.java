package com.majesty.os;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class PCWindowManager {

    private Context context;
    private ViewGroup rootLayout;

    // Конструктор: кажемо менеджеру, де саме на екрані малювати вікна
    public PCWindowManager(Context context, ViewGroup rootLayout) {
        this.context = context;
        this.rootLayout = rootLayout;
    }

    // Головна функція створення нового вікна ПК
    public void openNewWindow(String title, View content) {
        LayoutInflater inflater = LayoutInflater.from(context);
        
        // Беремо наш дизайн вікна pc_window.xml
        final View windowView = inflater.inflate(R.layout.pc_window, rootLayout, false);

        // Встановлюємо заголовок вікна
        TextView titleView = windowView.findViewById(R.id.window_title);
        titleView.setText(title);

        // Знаходимо "контейнер" всередині вікна і кладемо туди вміст
        FrameLayout windowContent = windowView.findViewById(R.id.window_content);
        windowContent.removeAllViews();
        windowContent.addView(content);

        // Налаштовуємо кнопку закриття (червоний X)
        Button closeBtn = windowView.findViewById(R.id.close_window_btn);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Видаляємо вікно з екрана
                rootLayout.removeView(windowView);
            }
        });

        // Виводимо вікно на робочий стіл MajestyOS
        rootLayout.addView(windowView);
    }
}
