package com.majesty.os;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class BrowserStrip {

    // Ініціалізація браузера (вмикаємо всі круті фішки)
    public static void init(WebView webView, String startUrl) {
        WebSettings settings = webView.getSettings();
        
        // Дозволяємо сайтам працювати на повну
        settings.setJavaScriptEnabled(true); 
        settings.setDomStorageEnabled(true); // Важливо для сучасних сайтів
        settings.setLoadsImagesAutomatically(true);
        
        // Робимо так, щоб посилання відкривалися всередині лаунчера, а не в Chrome
        webView.setWebViewClient(new WebViewClient());

        // Завантажуємо стартову сторінку MajestyOS (або Google)
        webView.loadUrl(startUrl);
    }

    // Функція швидкого пошуку
    public static void loadNewPage(WebView webView, String url) {
        if (!url.startsWith("http")) {
            url = "https://www.google.com/search?q=" + url;
        }
        webView.loadUrl(url);
    }
}
