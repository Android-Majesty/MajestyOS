package com.majesty.os;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.List;

public class AppLoader {

    // Клас-контейнер для однієї програми
    public static class AppModel {
        public String label;      // Назва програми
        public Drawable icon;    // Іконка
        public String packageName; // "Адреса" для запуску
    }

    // Головна функція сканування
    public static List<AppModel> getInstalledApps(Context context) {
        List<AppModel> apps = new ArrayList<>();
        PackageManager pm = context.getPackageManager();
        
        // Шукаємо тільки ті програми, які можна запустити (мають іконку в меню)
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);

        for (ResolveInfo info : activities) {
            AppModel app = new AppModel();
            app.label = info.loadLabel(pm).toString();
            app.icon = info.loadIcon(pm);
            app.packageName = info.activityInfo.packageName;
            apps.add(app);
        }
        return apps;
    }
}
